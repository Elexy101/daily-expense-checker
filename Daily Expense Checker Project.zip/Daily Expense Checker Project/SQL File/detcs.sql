-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               6.0.4-alpha-community-log - MySQL Community Server (GPL)
-- Server OS:                    Win32
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping database structure for detsdb
CREATE DATABASE IF NOT EXISTS `detsdb` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `detsdb`;


-- Dumping structure for table detsdb.tblexpense
CREATE TABLE IF NOT EXISTS `tblexpense` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `UserId` int(10) NOT NULL,
  `ExpenseDate` date DEFAULT NULL,
  `ExpenseItem` varchar(200) DEFAULT NULL,
  `ExpenseCost` varchar(200) DEFAULT NULL,
  `NoteDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

-- Dumping data for table detsdb.tblexpense: ~30 rows (approximately)
/*!40000 ALTER TABLE `tblexpense` DISABLE KEYS */;
INSERT INTO `tblexpense` (`ID`, `UserId`, `ExpenseDate`, `ExpenseItem`, `ExpenseCost`, `NoteDate`) VALUES
	(1, 2, '2019-05-15', 'Milk', '63', NULL),
	(2, 2, '2019-05-15', 'Vegitables', '520', '2019-05-15 11:06:19'),
	(3, 2, '2019-05-15', 'Household Items', '5200', '2019-05-15 11:07:08'),
	(4, 2, '2019-05-14', 'Milk', '83', '2019-05-15 11:07:27'),
	(5, 2, '2019-05-14', 'Bed Sheets', '1120', '2019-05-15 11:07:49'),
	(6, 2, '2019-05-12', 'Fruits', '890', '2019-05-15 11:08:09'),
	(7, 2, '2019-05-10', 'Household Items', '5600', '2019-05-15 11:08:26'),
	(8, 2, '2019-04-24', 'Milk', '102', '2019-05-15 11:08:44'),
	(9, 2, '2019-05-08', 'Bed Sheets', '890', '2019-05-15 11:08:57'),
	(10, 2, '2018-12-19', 'Household Items', '1120', '2019-05-15 11:09:34'),
	(11, 2, '2018-12-19', 'Fruits', '560', '2019-05-15 11:09:52'),
	(13, 2, '2018-12-20', 'Tour of Manali', '30000', '2019-05-15 11:15:47'),
	(14, 2, '2019-05-14', 'Milk', '360', '2019-05-15 11:21:31'),
	(15, 3, '2019-05-15', 'Milk', '123', '2019-05-15 11:29:56'),
	(16, 3, '2019-05-15', 'Household Items', '360', '2019-05-15 11:30:06'),
	(17, 3, '2019-05-15', 'Bed Sheets', '3000', '2019-05-15 11:30:18'),
	(18, 3, '2019-05-07', 'Milk', '123', '2019-05-15 11:30:28'),
	(19, 3, '2019-05-14', 'Household Items', '3600', '2019-05-15 11:30:38'),
	(20, 2, '2019-05-14', 'Electric Board Extension', '300', '2019-05-15 16:11:33'),
	(21, 2, '2019-04-11', 'Milk', '123', '2019-05-15 18:50:24'),
	(22, 2, '2019-04-10', 'Household Items', '520', '2019-05-15 18:50:37'),
	(23, 2, '2019-05-16', 'Household Items', '360', '2019-05-16 08:29:54'),
	(25, 8, '2019-05-17', 'Milk', '3600', '2019-05-17 06:35:13'),
	(26, 8, '2019-05-16', 'Bed Sheets', '1025', '2019-05-17 06:35:42'),
	(27, 1, '2019-05-17', 'Computer Mouse', '500', '2019-05-18 06:19:05'),
	(30, 1, '2019-05-18', 'Milk + Bread', '80', '2019-05-18 06:22:01'),
	(31, 10, '2019-05-16', 'Computer Mouse', '500', '2019-05-18 06:35:45'),
	(32, 10, '2019-05-17', 'Milk+Bread', '80', '2019-05-18 06:36:06'),
	(33, 10, '2019-05-18', 'Room Rent', '10000', '2019-05-18 06:36:26'),
	(35, 11, '2019-11-06', 'Indomie Full Carton', '1900', '2019-11-06 14:31:49');
/*!40000 ALTER TABLE `tblexpense` ENABLE KEYS */;


-- Dumping structure for table detsdb.tbluser
CREATE TABLE IF NOT EXISTS `tbluser` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `FullName` varchar(150) DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `Password` varchar(200) DEFAULT NULL,
  `gender` varchar(100) DEFAULT NULL,
  `RegDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

-- Dumping data for table detsdb.tbluser: ~3 rows (approximately)
/*!40000 ALTER TABLE `tbluser` DISABLE KEYS */;
INSERT INTO `tbluser` (`ID`, `FullName`, `Email`, `MobileNumber`, `Password`, `gender`, `RegDate`) VALUES
	(10, 'Test User demo', 'testuser@gmail.com', 987654321, 'f925916e2754e5e03f75dd58a5733251', '', '2019-05-18 06:34:53'),
	(11, 'Emmanuel Linus Ekpe', 'emmanuellinus013@gmail.com', 8120313674, '8971991380db981036937d4e3c552778', 'Male', '2019-11-06 14:30:37'),
	(12, 'Happy', 'happy@yahoo.com', 8033013712, '8971991380db981036937d4e3c552778', 'Female', '2019-11-08 01:22:09');
/*!40000 ALTER TABLE `tbluser` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
