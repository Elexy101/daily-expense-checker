<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if(isset($_POST['login']))
  {
    $email=$_POST['email'];
    $password=md5($_POST['password']);
    $query=mysqli_query($con,"select ID from tbluser where  Email='$email' && Password='$password' ");
    $ret=mysqli_fetch_array($query);
    if($ret>0){
      $_SESSION['detsuid']=$ret['ID'];
     header('location:dashboard.php');
    }
    else{
    $msg="<i class='fa fa-times-circle'></i> Invalid Details.";
    }
  }
  ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Daily Expense Checker - Login</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/datepicker3.css" rel="stylesheet">
	<link href="css/font-awesome.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
		<link href="//fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Raleway:400,500,600,700" rel="stylesheet">
	
</head>
<body style="background-image: url('./5copy.jpg')">
	<div class="agile-login">
		<center><a href="index.php"><img class="agile-img" src="favicon.png" alt="logo" style="width: 3em; border-radius: 2em" class="img-responsive"></a> <font color="#59aa55"><h3>Daily Expense</h3></font></center><br>
		<div class="wrapper">
			<h2>Sign In</h2>
								<p style="font-size:16px; color:red" align="center"> <?php if($msg){
    echo $msg;
  }  ?> </p>
			<div class="w3ls-form">
				<form role="form" action="" method="post" id="" name="login">
					<label>Username</label>
					<input type="email" name="email" class="form-control" placeholder="Email" required/>
					<label>Password</label>
					<input type="password" class="form-control" name="password" placeholder="Password" required />
					<a href="register.php" class="pass">Not Registered?</a>
					<input type="submit" name="login" value="Log In" />
				</form>
			</div>
			
			<div class="agile-icons">
				<a href="#"><span class="fa fa-twitter" aria-hidden="true"></span></a>
				<a href="#"><span class="fa fa-facebook"></span></a>
				<a href="#"><span class="fa fa-pinterest-p"></span></a>
			</div>
		</div>
		<br>
		<div class="copyright">
		<p>&copy; <?php echo @date("Y") ?> Daily Expense Checker. All rights reserved | Design by <a style="color: #38c75c" href="facebook.com/">Emmanuel Ekpe</a></p> 
	</div>
	</div>
	
</body>
</html>