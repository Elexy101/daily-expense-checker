<?php 
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if(isset($_POST['submit']))
  {
    $fname=$_POST['name'];
    $mobno=$_POST['mobilenumber'];
    $email=$_POST['email'];
    $gender = $_POST['gender'];
    $password=md5($_POST['password']);

    $ret=mysqli_query($con, "select Email from tbluser where Email='$email' ");
    $result=mysqli_fetch_array($ret);
    if($result>0){
$msg="<i class='fa fa-times-circle'></i> This email  associated with another account";
    }
    else{
    $query=mysqli_query($con, "insert into tbluser(FullName, MobileNumber, Email,gender,  Password) value('$fname', '$mobno', '$email','$gender', '$password' )");
    if ($query) {
    $msg2="<i class='fa fa-check-circle-o'></i> You have successfully registered";
  }
  else
    {
      $msg="<i class='fa fa-times-circle'></i> Something Went Wrong. Please try again";
    }
}
}

 ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Daily Expense Checker - Signup</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/datepicker3.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<script type="text/javascript">
function checkpass()
{
if(document.signup.password.value!=document.signup.repeatpassword.value)
{
alert('Password and Repeat Password field does not match');
document.signup.repeatpassword.focus();
return false;
}
return true;
} 

</script>
<body style="background-image: url('./5copy.jpg')">
	<div class="agile-login">
		<center><a href="resgister.php"><img class="agile-img" src="favicon.png" alt="logo" style="width: 3em; border-radius: 2em" class="img-responsive"></a> <font color="#59aa55"><h3>Daily Expense</h3></font></center><br>
		<div class="wrapper">
			<h2>Sign Up</h2>
		
			<div class="w3ls-form">
				<form role="form" action="" method="post" id="" name="signup" onsubmit="return checkpass();">
						<p style="font-size:16px; color:red" align="center"> <?php if($msg){
    echo $msg;
  }  ?> </p>
							<label>Full Name</label>
								<input class="form-control" placeholder="Full Name" name="name" type="text" required="true">
							
							<label>Email</label>
								<input class="form-control" placeholder="E-mail" name="email" type="email" required="true">
							<label>Gender</label>
							<select name="gender" class="form-control"><option value="Male">Male<option value="Female">Female</select>
							
							
							<label>Mobile Number</label>
								<input type="number" class="form-control" id="mobilenumber" name="mobilenumber" placeholder="Mobile Number" maxlength="11" pattern="[0-9]{10}" required="true">
							
							<label>Password</label>
								<input class="form-control" placeholder="Password" name="password" type="password" value="" required="true">
							
							<label>Repeat Password</label>
								<input type="password" class="form-control" id="repeatpassword" name="repeatpassword" placeholder="Repeat Password" required="true">
							
							<div class="checkbox">
								<input type="submit" value="Register" name="submit" class="btn btn-primary">
								<a href="index.php" class="btn btn-primary pull-right"><i class="fa fa-sign-in"></i> Login</a>
							</div>
							 
					</form>
			</div>
			
			<div class="agile-icons">
				<a href="#"><span class="fa fa-twitter" aria-hidden="true"></span></a>
				<a href="#"><span class="fa fa-facebook"></span></a>
				<a href="#"><span class="fa fa-pinterest-p"></span></a>
			</div>
		</div>
		<br>
		<div class="copyright">
		<p>&copy; <?php echo @date("Y") ?> Daily Expense Checker. All rights reserved | Design by <a style="color: #38c75c" href="facebook.com/">Emmanuel Ekpe</a></p> 
	</div>
	</div>
	
</body>
</html>