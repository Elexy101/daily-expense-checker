<?php
session_start();
//------------------------Including Database----------------------

include './dbcon.php';
$username = mysql_escape_string(ucwords(trim($_POST['username'])));
$password = mysql_escape_string(trim($_POST['password']));
$password = md5($password);
$db_name = "rentalmanagement";
$tb_name = "admin";
$time = @date("F j, Y, g:i a");
//------------------------End------------------------
if($_GET['logout'] == "true"){
$expire = time() - 3600;
setcookie('business_greenstory', '', $expire);
}
if($_COOKIE['business_greenstory']){
	echo "<script language='javascript'>location.href='shop/dashboard/feeds_intro.php?username=".$_COOKIE['business_greenstory']."'</script>";
}
if(isset($_POST["submit"])){	
$_SESSION['status_id'] = $username;
//Getting username and password information from the specified user.
//-----------------------------------------------------------------------------------------
$sql = "SELECT * FROM membership_users WHERE memberID = '$username' AND passMD5 = '$password'";
$result = mysql_query($sql) or die(mysql_error($connection));
$result_login = mysql_fetch_array($result);
//-----------------------------------------------------------------------------------------
if (empty($username)){
echo "<li><font color='red'><center>Please enter your username!</center></font></li>";
}
//End of Restriction Process
else if (empty($password)){
echo "<li><font color='red'><center>Please enter your password!</center></font></li>";
}
else if($result_login['block_access']== "yes"){
	echo "<script language='Javascript'>window.alert('Sorry, your hourbusiness account has been blocked due to not abiding by the rules/policies of hourstories.');</script>";
}
if (mysql_num_rows($result) > 0) {
	
$_COOKIE['business_greenstory'] = $username;
$_COOKIE['logged'] = 1;
//Creating and Watching user's session and login activity + Timestamp SessionHandler
//-----------------------------------------------------------------------------------------
$sql_watch = "INSERT INTO login_activity(id,user,date) VALUES (id,'$result_login[user]','$time')" or die(mysql_error());
$query_watch = mysql_query($sql_watch,$connection);
$expire = time() + 30 * 24 * 60 * 60;
setcookie('business_greenstory', $username, $expire);
//-----------------------------------------------------------------------------------------
echo "<script language='javascript'>location.href='shop/dashboard/feeds_intro.php?username=".$username."'</script>";
}
else{
echo "<html><script language='Javascript'>window.alert('Incorrect Login...You have supplied an invalid username and password.');</script></html>";
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>HourBusiness: The Business Platform</title>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Velvety Sign In Form Responsive Widget,Login form widgets, Sign up Web forms , Login signup Responsive web form,Flat Pricing table,Flat Drop downs,Registration Forms,News letter Forms,Elements" />
<link rel="stylesheet" href="./web/css/flexslider.css" type="text/css" media="screen" /> <!-- Flexslider-CSS -->
<link href="./web/css/font-awesome.css" rel="stylesheet"><!-- Font-awesome-CSS --> 
<link href="./web/css/style.css" rel='stylesheet' type='text/css'/><!-- Stylesheet-CSS -->
<link rel="stylesheet" href="./style/w3.css">
<link rel="icon" href="favicon.png" style="width: 2em"/>
<link href="//fonts.googleapis.com/css?family=Righteous" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Josefin+Sans:100,300,400,600,700" rel="stylesheet">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>	
</head>
<body onload="redirTimer();">
	<h1><a href="fitness/index.php">HourBusiness</a></h1>
	<div class="main-agile">
		
		<div class="content-wthree">
			<div class="about-middle">
			<section class="slider">
			<div class="flexslider">
				<ul class="slides">
				  <li>
					<div class="banner-bottom-2">			  		
							<div class="about-midd-main">
							<a href="../fitness/index.php"><img class="agile-img" src="favicon.png" alt="logo" style="width: 3em" class="img-responsive"></a>
							<h4><strong>Rent Store</strong></h4>
							<p>Own a rent store and worry not carrying papers around. save your tenant information here.</p>
						</div>
					</div>
				  </li>
				 <li>
					<div class="banner-bottom-2">			  		
						<div class="about-midd-main">
							<a href="../fitness/index.php"><img class="agile-img" src="favicon.png" alt="logo" style="width: 3em" class="img-responsive"></a>
							<h4><strong>Business Store</strong></h4>
							<p>Create a business store with Hourbusiness and advertise your product information online for publicity.</p>
						</div>
					</div>
				  </li>
				</ul>
			</div>
			<div class="clear"> </div>
		  </section>
		  <BR>
		  
		</div>
			</div>
		<div class="new-account-form">
		<h2 class="heading-w3-agile">Sign In</h2>
			<form method="post">
			<!-- Username !-->
			<div class="inputs-w3ls">
				<p>Username:</p>
				<i class="fa fa-user" aria-hidden="true"></i>
					<input type="text" class="w3-animate-input" name="username" maxlength="100" placeholder="Username" autocomplete="off" required="">
			</div>
			<!-- Email !-->
					<div class="inputs-w3ls">
				<p>Password:</p>
				<i class="fa fa-lock aria-hidden="true"></i>
					<input type="password" class="w3-animate-input" maxlength="100"  name="password" placeholder="Password" autocomplete="off" required="">
			</div>
			
	
				
						<button type="submit" class="w3-btn w3-btn-block" style="background-color: #d82c27" name="submit"><i class="fa fa-user"></i> Login</button>
						<br>
						<a href="./sign_up/free_signup.php" class="w3-btn w3-btn-block" style="background-color: #48b74b"><i class="fa fa-user-plus"></i> Create an account?</a><br>
							
			</form> 
		</div>
		<br>
					<a href="forgotten.php" style="color: #d82c27" class="pull-right w3-code"><i class="fa fa-lock"></i> Forgot Password?</a>	
		<div class="clear"> </div>
		</div>
	</div>
	<div class="footer-w3l">
		<p class="agileinfo"> &copy; <?php echo @date("Y") ?> Hourstories. All Rights Reserved | Designed by <b>HourStories Team</b></p>
	</div>
<script src="js/jquery.min.js"></script>
<script>$(document).ready(function(c) {
		$('.alert-close').on('click', function(c){
			$('.main-agile').fadeOut('slow', function(c){
				$('.main-agile').remove();
			});
		});	  
	});
</script>
	<!-- FlexSlider -->
				  <script defer src="js/jquery.flexslider.js"></script>
				  <script type="text/javascript">
					$(function(){
					 
					});
					$(window).load(function(){
					  $('.flexslider').flexslider({
						animation: "slide",
						start: function(slider){
						  $('body').removeClass('loading');
						}
					  });
					});
				  </script>
		<!-- FlexSlider -->

</body>
</html>